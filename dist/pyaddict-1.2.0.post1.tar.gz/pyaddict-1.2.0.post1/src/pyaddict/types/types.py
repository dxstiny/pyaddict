# -*- coding: utf-8 -*-
"""pyaddict"""

__copyright__ = "Copyright (c) 2022 https://github.com/dxstiny"

from typing import Any, Dict, List

JObject = Dict[str, Any]
JArray = List[Any]
