# -*- coding: utf-8 -*-
"""pyaddict"""

__copyright__ = "Copyright (c) 2022 https://github.com/dxstiny"

from pyaddict.types.types import *
